function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  noLoop();
  noFill();
  for(i = 0; i < 12; i++) {
    for(j = 0; j < 12; j++) {
      push();
      translate(10 + i * 32, 10 + j * 32);
      rotate(randomGaussian(0, 0.04) * j);
      square(0, 0, 30);
      pop();
    }
  }
}